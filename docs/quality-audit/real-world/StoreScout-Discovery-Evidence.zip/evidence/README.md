# StoreScout discovery measurement evidence

Measured 2026-09-05, frozen clock 20:44:23.705755 UTC. Application baseline ff555bb; production index read-only. See the two accompanying Markdown reports for interpretation and limitations.

## Files

- `measured-manifest.json`: completed execution/provenance; `premeasurement-baseline-manifest.json` is preserved historical preparation and intentionally still says blocked/null.
- `index-snapshot.json`: 38,221 allowlisted public business/catalog rows in PostgreSQL export order. Top-level null keys were omitted for transfer; the adapter restores missing selected keys to null. Null/empty lists remain distinct. Do not feed this snapshot or newer public observations into production.
- `census-initial.json`, `export-end.json`, `export-projection.txt`: schema/census/reconciliation and exported-field scope.
- `census-analysis.json`: complete distributions, metadata, age and collision diagnostics.
- `retrieval-readonly.sql`, `retrieval-postgres.json`: actual PostgreSQL read-only candidate queries/captures.
- `reference-panel.json`: the unchanged original independent panel, not revised from output.
- `replay-plan.json`: original planned inputs plus classifier/retrieval terms; its inherited blocked/result-null fields are historical. Completed status/results are in `replay-results.json`.
- `replay-results.json`: all 50 actual original-endpoint executions, original input/profile context, query errors, channel row order, full ranked candidate traces, exclusions, reference stages and final responses.
- `relevance-labels.json`: every returned placement's public-evidence judgment, limitations and source URLs. One analyst, not a fully blinded independent review.
- `benchmark-metrics.json`, `case-metrics.csv`: aggregate, family and individual metrics for both modes.
- `health-sample.json`, `public-health-summary.json`, `classification-review.json`: sample membership, strata/weights, estimates, uncertainty and classification review.
- `public-evidence-compact.json`: retained factual public URLs, observation times, HTTP/redirect/canonical/platform evidence, product counts and bounded product title/type examples. Full scraped page text and raw product bodies are omitted. All 353 observed domains are retained. A failed access attempt is not a dead-store finding.
- Python scripts document the preparation, scoring and checks. They are measurement utilities, not production patches.

## Recompute without database or network access

Extract this archive into a working directory so the data reside under `evidence/`.

`python3 evidence/analyze_census.py` rebuilds the exact census from the snapshot.

`python3 evidence/measure.py` rebuilds discovery metrics/CSV from saved original endpoint results and labels. It does not relabel the merchants or change reference truth.

To rerun the actual endpoint locally, point `ROOT` in `evidence/replay.py` at a checkout matching the five source hashes in the measured manifest, use that project's already-installed Python dependencies, and run it from the extraction directory. The script denies network, mutation and paid-model paths and uses saved real PostgreSQL channel captures. Do not replace these captures with a casual Python approximation of PostgreSQL semantics. It does not need credentials. The original session used `/workspace/scratch/ecb90441df09/storescout-venv/bin/python` and the preserved checkout at `/workspace/scratch/afcda1e6eea5/StoreScout`.

`prepare_replay.py` documents preparation; it is not needed for metric recomputation. Public-check and label-review scripts document the observed methodology; they originally consumed full temporary public observations. Those raw scraped bodies are intentionally not archived. Re-running network checks would generate a NEW dated observation, not reproduce September 5 content. The compact factual observations and finalized labels remain the review record. Population health estimates can be independently recomputed from compact per-domain flags plus sample inclusion weights. The parked aether.run flag includes manual confirmation of its domain-broker redirect.

## Integrity and limits

`SHA256SUMS.json` covers every archive member except itself. Source code remains in the external Git checkout rather than being duplicated here. The snapshot was paginated, not atomic, with reconciled count/latest update/domain timestamp checks. Metrics use source-default thresholds and a frozen clock, not uninspected deployed environment overrides. Structured mode is `sells` plus the independent source summary in `notes`; no website enrichment or paid AI was executed. Alternate phrasing and live authenticated paths were not evaluated. Labels are analyst judgments with partial-fit and geography/price limitations. Keep the original panel's ground truth separate from diagnostic candidates.
